package com.example.demo4;

import javafx.application.Application;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import javafx.stage.DirectoryChooser;
import javafx.scene.Scene;
import javafx.scene.layout.VBox;
import javafx.scene.control.Button;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;
import java.util.zip.ZipInputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

public class ZipUtilityApp extends Application {
    private File[] selectedFilesToZip = null;
    private File selectedZipFile = null;
    private File selectedUnzipLocation = null;
    @Override
    public void start(Stage primaryStage) {

        VBox vbox = new VBox(10);

        Button chooseFilesButton = new Button("Wybierz pliki do spakowania");
        chooseFilesButton.setOnAction(e -> {
            FileChooser fileChooser = new FileChooser();
            selectedFilesToZip = fileChooser.showOpenMultipleDialog(primaryStage).toArray(new File[0]);
        });

        Button chooseSaveButton = new Button("Wybierz miejsce zapisania ZIP");
        chooseSaveButton.setOnAction(e -> {
            FileChooser fileChooser = new FileChooser();
            fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("ZIP Files", "*.zip"));
            selectedZipFile = fileChooser.showSaveDialog(primaryStage);
        });

        Button zipButton = new Button("Spakuj pliki");
        zipButton.setOnAction(e -> {
            if (selectedFilesToZip != null && selectedZipFile != null) {
                try {
                    zipFiles(selectedFilesToZip, selectedZipFile);
                } catch (IOException ex) {
                    // Handle error silently or log
                }
            }
        });

        Button chooseZipButton = new Button("Wybierz plik ZIP do rozpakowania");
        chooseZipButton.setOnAction(e -> {
            FileChooser fileChooser = new FileChooser();
            fileChooser.getExtensionFilters().add(new FileChooser.ExtensionFilter("ZIP Files", "*.zip"));
            selectedZipFile = fileChooser.showOpenDialog(primaryStage);
        });

        Button chooseUnzipLocationButton = new Button("Wybierz folder do rozpakowania");
        chooseUnzipLocationButton.setOnAction(e -> {
            DirectoryChooser directoryChooser = new DirectoryChooser();
            selectedUnzipLocation = directoryChooser.showDialog(primaryStage);
        });

        Button unzipButton = new Button("Rozpakuj ZIP");
        unzipButton.setOnAction(e -> {
            if (selectedZipFile != null && selectedUnzipLocation != null) {
                try {
                    unzipFile(selectedZipFile, selectedUnzipLocation);
                } catch (IOException ex) {
                    // Handle error silently or log
                }
            }
        });

        vbox.getChildren().addAll(
                chooseFilesButton,
                chooseSaveButton,
                zipButton,
                chooseZipButton,
                chooseUnzipLocationButton,
                unzipButton
        );

        Scene scene = new Scene(vbox, 400, 300);
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    private void zipFiles(File[] files, File zipFile) throws IOException {
        try (ZipOutputStream zos = new ZipOutputStream(new FileOutputStream(zipFile))) {
            for (File file : files) {
                try (FileInputStream fis = new FileInputStream(file)) {
                    ZipEntry entry = new ZipEntry(file.getName());
                    zos.putNextEntry(entry);
                    byte[] buffer = new byte[1024];
                    int length;
                    while ((length = fis.read(buffer)) >= 0) {
                        zos.write(buffer, 0, length);
                    }
                    zos.closeEntry();
                }
            }
        }
    }

    private void unzipFile(File zipFile, File destination) throws IOException {
        try (ZipInputStream zis = new ZipInputStream(new FileInputStream(zipFile))) {
            ZipEntry entry;
            while ((entry = zis.getNextEntry()) != null) {
                Path path = Paths.get(destination.getAbsolutePath(), entry.getName());
                Files.createDirectories(path.getParent());
                try (FileOutputStream fos = new FileOutputStream(path.toFile())) {
                    byte[] buffer = new byte[1024];
                    int length;
                    while ((length = zis.read(buffer)) >= 0) {
                        fos.write(buffer, 0, length);
                    }
                }
                zis.closeEntry();
            }
        }
    }

    public static void main(String[] args) {
        launch(args);
    }
}
